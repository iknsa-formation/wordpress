<div class="wrap">
  <div id='imcron_header'>
  	<div id="icon-imcron" class="icon32"><br></div>
    <h2>Improved Cron</h2>
  </div>

  <?php require_once( $inner_page ); ?>

  <div id='imcron_footer'>
		<br/>
		<h3>Additional Information</h3>
		<ul>
			<li><a href="http://paulswebsolutions.com/portfolios/improved-cron/">Instructions</a></li>
			<li><a href="http://paulswebsolutions.com/portfoliosets/wordpress-plugins">My Other Plugins</a></li>
			<li><a href="http://paulswebsolutions.com/contact">Contact Me</a></li>
		</ul>
		<br/>
</div>

