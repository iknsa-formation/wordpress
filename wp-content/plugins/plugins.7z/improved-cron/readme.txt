=== Improved Cron ===
Contributors: cpkwebsolutions
Donate link: http://cpkwebsolutions.com/donate
Tags: cron, ping, scheduled, jobs, view, wp_cron, task
Requires at least: 3.3
Tested up to: 3.5.1
Stable tag: 1.2.0

Improve the reliability of WP Cron for scheduled tasks.

== Description ==

Cron not running when you expect?  This plugin may help.  Also provides insight into WP Cron exactly like the Cron View plugin.

This plugin will visit your site every minute and thereby ensure that your cron jobs run on time.  It is mostly intended for people who can't use real cron for some reason.

Note: This is the exact same plugin that was previously sold on <a href='http://codecanyon.net?ref=paulswebsolutions'>Code Canyon</a>.

== Installation ==

1. Either use the built-in plugin installer, or download the zip and extract to your 'wp-content/plugins' folder.
2. Activate the plugin in Plugins > Installed Plugins
3. Open the 'Improved Cron' main menu item on the left side of your Wordpress dashboard

== Frequently Asked Questions ==

No FAQs yet.

== Screenshots ==

No screenshots available.

== Changelog ==

= 1.2.0 =
* Transferred from <a href='http://codecanyon.net?ref=paulswebsolutions'>Code Canyon</a>

== Upgrade Notice ==  
